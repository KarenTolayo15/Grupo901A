﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IdentityManager.Service
{
    public class MailJetOptions
    {
        public string ApiKey { get; set; }
        public string SecretKey { get; set; }
    }
}
